/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.netproj.lostandfound;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author davee
 */
public class ObjDBhelper {
    Connection con = null;    
    Statement st = null;
   
    public void connectDB() throws Exception{
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_lost_found?zeroDateTimeBehavior=CONVERT_TO_NULL","root","");
        System.out.println("Connected to Database Successfully");
    }
    public void disconnectDB() throws Exception{
        try{
            con.close();
        }
        catch(Exception ex){
            Logger.getLogger(Obj.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    public boolean addObject(Obj obj){
        boolean val = false;
        try{
            st = con.createStatement();
            String cmd = "INSERT INTO db_lost_found.tbl_object "
                    + "(object_name, object_description, object_location, submitted_time, "
                    + "object_status, poster, poster_contact) " + "VALUES('"
                    + ""+ obj.getObjectName() +"', '"+ obj.getObjectDescription()+"', '"
                    + obj.getObjectLocation() + "', "
                    + "CURRENT_TIMESTAMP, '"+ obj.getObjectStatus()+"', "
                    + "'"+ obj.getPoster()+"', '"+ obj.getPosterContact() +"' )";
            if(st.executeUpdate(cmd) > 0){
               val = true;
               System.out.println("register successful");
            }
        }
        catch(Exception ex){
            Logger.getLogger(Obj.class.getName()).log(Level.SEVERE, null, ex);
        }
        return val;
    } 
    
        public boolean CloseObj(int objId){
        boolean val = false;
        try{
            st = con.createStatement();
            String cmd = "UPDATE db_lost_found.tbl_object SET object_status='CLOSED' WHERE "
                + " object_id = '"+ objId +"' ";
            if(st.executeUpdate(cmd) > 0){
               val = true;
               System.out.println("update successful");
            }
        }
        catch(Exception ex){
            Logger.getLogger(Obj.class.getName()).log(Level.SEVERE, null, ex);
        }
        return val;
    } 
        public boolean DeleteObj(int objId){
        boolean val = false;
        try{
            st = con.createStatement();
            String cmd = "DELETE FROM db_lost_found.tbl_object WHERE "
                + " object_id = '"+ objId +"' ";
            if(st.executeUpdate(cmd) > 0){
               val = true;
               System.out.println("Delete successful");
            }
        }
        catch(Exception ex){
            Logger.getLogger(Obj.class.getName()).log(Level.SEVERE, null, ex);
        }
        return val;
    } 

    public ResultSet executeStringQuery(String sql){
           ResultSet rs = null;
           try {
           st = con.createStatement();
           rs = st.executeQuery(sql);
           } catch (SQLException ex) {
             Logger.getLogger(Obj.class.getName()).log(Level.SEVERE, null, ex);
          }
          return rs;
         
        }
    public ResultSet displayLost(){
        ResultSet rs = null;    
        try {
                st = con.createStatement();
                String cmd = "SELECT object_name, object_description, object_location, poster, poster_contact, submitted_time FROM db_lost_found.tbl_object WHERE object_status = 'LOST'";
                 rs = st.executeQuery(cmd);
            } catch (SQLException ex) {
                Logger.getLogger(Obj.class.getName()).log(Level.SEVERE, null, ex);
            }
        return rs;
    }
    
    public ResultSet displayFound(){
        ResultSet rs = null;    
        try {
                st = con.createStatement();
                String cmd = "SELECT object_name, object_description, object_location, poster, poster_contact, submitted_time FROM db_lost_found.tbl_object WHERE object_status = 'FOUND'";
                 rs = st.executeQuery(cmd);
            } catch (SQLException ex) {
                Logger.getLogger(Obj.class.getName()).log(Level.SEVERE, null, ex);
            }
        return rs;
    }
    
    public ResultSet displayAll(){
        ResultSet rs = null;    
        try {
                st = con.createStatement();
                String cmd = "SELECT object_id, object_name, object_description, object_location, poster, poster_contact, submitted_time, object_status FROM db_lost_found.tbl_object";
                 rs = st.executeQuery(cmd);
            } catch (SQLException ex) {
                Logger.getLogger(Obj.class.getName()).log(Level.SEVERE, null, ex);
            }
        return rs;
    }
    
}
