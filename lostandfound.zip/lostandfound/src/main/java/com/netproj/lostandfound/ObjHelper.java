/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

package com.netproj.lostandfound;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author davee
 */

public class ObjHelper {

    private Connection connection;
    
    public ObjHelper() {
        try {
            String url = "jdbc:mysql://localhost:3306/db_lost_found";
            String user = "root";
            String password = "";
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void saveDetails(int id, String objectName, String location, String contactPerson, String contactInfo, String objectDescription, Date closeDate) {
        try {
            String sql = "INSERT INTO object_details (object_name, location, contact_person, contact_info, object_description, close_date) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, objectName);
                preparedStatement.setString(2, location);
                preparedStatement.setString(3, contactPerson);
                preparedStatement.setString(4, contactInfo);
                preparedStatement.setString(5, objectDescription);
                preparedStatement.setTimestamp(6, new java.sql.Timestamp(closeDate.getTime()));

                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // ... existing code ...
}
