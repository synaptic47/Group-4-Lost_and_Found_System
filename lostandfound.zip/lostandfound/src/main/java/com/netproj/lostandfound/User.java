/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.netproj.lostandfound;


public class User {
    private int user_id;
    private String username;
    private String password;
    
    public User(){}
    
    public User(int user_id, String username, String password){
        this.user_id = user_id;
        this.username = username;
        this.password = password;
    }
    
    public User( String username, String password){
        this.username = username;
        this.password = password;
    }
    
    public int getUserId(){
        return user_id;
    }
    
    public String getUsername(){
        return username;
    }
    
    public String getPassword(){
        return password;
    }
    
    
    public void setUserId(int user_id){
        this.user_id = user_id;
    }
    
    public void setUsername(String username){
        this.username = username;
    }
    
    public void setPassword(String password){
        this.password = password;
    }
    
    
    
}
