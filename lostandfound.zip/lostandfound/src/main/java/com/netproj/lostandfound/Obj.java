/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.netproj.lostandfound;
import java.sql.Date;

public class Obj {
    private int object_id;
    private String object_name;
    private String object_description;
    private String object_location;
    private Date submitted_time;
    private String poster;
    private String poster_contact;
    private String object_status;
    
    
    public Obj(){
    }
    public Obj(int object_id, String object_name, String object_description, Date submitted_time,
            String object_status, String poster, String poster_contact){
        this.object_id = object_id;
        this.object_name = object_name;
        this.object_description = object_description;
        this.submitted_time = submitted_time;
        this.object_status = object_status;
        this.poster = poster;
        this.poster_contact = poster_contact;
    }
    
    public Obj( String object_name, String object_description, String object_location, String object_status, String poster, String poster_contact){
        this.object_name = object_name;
        this.object_description = object_description;
        this.object_status = object_status;
        this.object_location = object_location;
        this.poster = poster;
        this.poster_contact = poster_contact;
    }
    
    public int getObjectId(){
        return object_id;
    }
    
    public String getObjectName(){
        return object_name;
    }
    
    public String getObjectDescription(){
        return object_description;
    }
    
    public Date getSubmittedTime(){
        return submitted_time;
    }
    
    public String getObjectStatus(){
        return object_status;
    }
    
    public void setObjectId(int object_id){
        this.object_id=object_id;
    }
    
    public void setObjectName(String object_name){
        this.object_name=object_name;
    }
    
    public void setObjectDescription(String object_description){
        this.object_description=object_description;
    }
    
    public String getObjectLocation(){
        return this.object_location;
    }
    
    public void setObjectLocation(String object_location){
        this.object_location = object_location;
    }
    
    public void getSubmittedTime(Date submitted_time){
        this.submitted_time=submitted_time;
    }
    
    public void getObjectStatus(String object_status){
        this.object_status=object_status;
    }
    
    public String getPoster(){
        return this.poster;
    }
    
    public void setPoster(String poster){
        this.poster = poster;
    }
    
    
    public String getPosterContact(){
        return this.poster_contact;
    }
    
    public void setPosterContact(String poster_contact){
        this.poster_contact = poster_contact;
    }
}
