/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.netproj.lostandfound;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class UserDBHelper {
    Connection con = null;    
    Statement st = null;
   
    public void connectDB() throws Exception{
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_lost_found?zeroDateTimeBehavior=CONVERT_TO_NULL","root","");
        System.out.println("Connected to Database Successfully");
    }
    public void disconnectDB() throws Exception{
        try{
            con.close();
        }
        catch(Exception ex){
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
       public boolean registerUser(User user){
        boolean val = false;
        try{
            st = con.createStatement();
            String cmd = "INSERT INTO db_lost_found.tbl_user (username, password) VALUES ('"+ user.getUsername() +"', '"+ user.getPassword()+"')";
            System.out.println("cmd is " + cmd);
            if(st.executeUpdate(cmd) > 0){
               val = true;
               System.out.println("register successful");
            }
        }
        catch(Exception ex){
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return val;
    }        

        public ResultSet executeStringQuery(String sql){
           ResultSet rs = null;
           try {
           st = con.createStatement();
           rs = st.executeQuery(sql);
           } catch (SQLException ex) {
             Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
          }
          return rs;
         
        }
}
